import 'package:flutter/material.dart';

class AColor {
  Color White = Colors.white;
  Color Black = Colors.black;
  Color Indigo = Colors.indigo;
  Color indigo_Accent700 = Colors.indigoAccent.shade700;
  Color grey300 = Colors.grey.shade300;
  Color grey700 = Colors.grey.shade700;
  Color Grey = Colors.grey;
  Color grey400 = Colors.grey.shade400;
  Color grey50 = Colors.grey.shade50;
  Color grey100 = Colors.grey.shade100;
  Color grey200 = Colors.grey.shade200;

  Color purple50 = Colors.purple.shade50;

  Color indigo50 = Colors.indigo.shade50;

  Color green = Color(0xFF00C853);

  Color green100 = Colors.green.shade100;

  Color Red = Colors.red;
}
