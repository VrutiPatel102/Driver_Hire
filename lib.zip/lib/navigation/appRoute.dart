class AppRoute{
  static const splash="Splash_Screen";
  static const chooseScreen="Choose_Screen";
  static const login="Login_Screen";
  static const register ="Register_screen";
  static const forgotPassword ="Forgot_password";
  static const otp ="Otp_screen";

  static const resetPwd ="ResetPwd_screen";
  static const pwdChanged ="pwdchanged_screen";

  static const bottombar  ="bottombar_screen";
  static const driverBooking ="driver_booking";
  static const driverBottombar ="driverbottombar_screen";

  static const waitingDriver ="waiting_driver_screen";
  static const userRideDetailScreen ="UserRideDetail_screen";
  static const rideRequestDetailScreen = "RideRequestDetail_Screen";
  static const driverRideDetailScreen = "DriverRideDetail_Screen";
  static const personalData = "PersonalData_Screen";
  static const driverPersonalData = "DriverPersonalData_Screen";

  static const setting = "setting_Screen";
  static const privacyPolicy = "privacyPolicy_Screen";
  static const termsAndCondition = "termsAndCondition_Screen";


}